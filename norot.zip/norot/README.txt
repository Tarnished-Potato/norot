Regionkit is suggested but not needed

How to use this to remove rot.

First, you want to find your the ID of your slugcat, this is found in the .json file with slugbase, if that's what you're using. For example Survivor is "white" Spearmaster is "spear" Monk is "yellow..." 
With this, go to the "world :/ ss" file and change any parts that have [SLUGCAT_ID] to your slugcat ID, for example map_ss-[SLUGCAT_ID].png will be map_ss-vinki.png for The Vinki.
You will also need to go into the "modify :/ world :/ ss :/ world_ss.txt" file and change everything there. 

Garbage Wastes C09 room will be implimented soon, the room c09 is fully unrotted already and will be in the files.

These rooms come from a mod I made, Fortunate Development. This mod was then imported into The Vinki and was expanded on. If you do use this mod I ask for credits to me, and The Vinki.

If there are any question feel free to contact me on discord at "tarnpot"
